# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2023 The Pybricks Authors

"""Robotics module for the Pybricks API."""

from __future__ import annotations

from typing import Tuple, Optional, overload, TYPE_CHECKING

from . import _common
from .parameters import Stop

if TYPE_CHECKING:
    from ._common import Motor, MaybeAwaitable
    from .parameters import Number


class DriveBase:
    """動く車輪が2つあるロボットの乗り物です。
    必要に応じて、補助の車輪やキャスターを付けることもできます。

    ロボットの大きさを指定することで、このクラスを使えば、
    ミリメートルで指定した距離を進んだり、指定した角度で
    曲がったりすることが簡単にできます。

    **プラス**の距離、半径（はんけい）、進む速さは
    **前進**を意味します。**マイナス**は**後退**を意味します。

    **プラス**の角度と回転の速さは、**右**に曲がることを意味します。
    **マイナス**は**左**です。上から見ると、プラスは時計回り、
    マイナスは反時計回りということです。

    直径（ちょっけい）と車軸の幅の値のはかり方や調整のヒントは、
    `measuring`_ のセクションを見てください。
    """

    distance_control = _common.Control()
    """The traveled distance and drive speed are controlled by a PID
    controller. You can use this attribute to change its settings.
    See the :ref:`motor control <settings>` attribute for an overview of
    available methods. The ``distance_control`` attribute has the same
    functionality, but the settings apply to every millimeter driven by the
    drive base, instead of degrees turned by one motor."""

    heading_control = _common.Control()
    """The robot turn angle and turn rate are controlled by a PID
    controller. You can use this attribute to change its settings.
    See the :ref:`motor control <settings>` attribute for an overview of
    available methods. The ``heading_control`` attribute has the same
    functionality, but the settings apply to every degree of rotation of the
    whole drive base (viewed from the top) instead of degrees turned by one
    motor."""

    def __init__(
        self,
        left_motor: Motor,
        right_motor: Motor,
        wheel_diameter: Number,
        axle_track: Number,
    ):
        """DriveBase(left_motor, right_motor, wheel_diameter, axle_track)

        Arguments:
            left_motor (Motor):
                左の車輪を動かすモーター。
            right_motor (Motor):
                右の車輪を動かすモーター。
            wheel_diameter (Number, mm): 車輪の直径。
            axle_track (Number, mm): 両方の車輪が地面に
                触れる点どうしの距離。
        """

    def drive(self, speed: Number, turn_rate: Number) -> None:
        """drive(speed, turn_rate)

        指定した速さと回転の速さで走り始めます。どちらの値も、
        ロボットの車輪の真ん中の点ではかったものです。

        Arguments:
            speed (Number, mm/s): ロボットの速さ。
            turn_rate (Number, deg/s): ロボットの回転の速さ。
        """

    def stop(self) -> None:
        """stop()

        ロボットを止めます。モーターが自由に回るようにします。"""

    def brake(self) -> None:
        """brake()

        モーターにブレーキをかけてロボットを止めます。
        """

    def distance(self) -> int:
        """distance() -> int: mm

        進んだ距離の推定値を返します。

        Returns:
            前回リセットしてから進んだ距離。
        """

    def angle(self) -> int:
        """angle() -> int: deg

        ドライブベースの回転角度の推定値を返します。

        Returns:
            前回リセットしてからの角度の合計。
        """

    def state(self) -> Tuple[int, int, int, int]:
        """state() -> Tuple[int, int, int, int]

        ロボットの状態を返します。

        Returns:
            ロボットの距離、進む速さ、角度、回転の速さのタプル。
        """

    def reset(self, distance: Number = 0, angle: Number = 0) -> None:
        """reset(distance=0, angle=0)

        進んだ距離と向きの角度の推定値をリセットします。

        これは :meth:`.stop` も呼び出して、実行中の動きを止めます。
        ロボットを :meth:`.use_gyro` で ``True`` に設定して
        制御（せいぎょ）している場合、このメソッドはジャイロも
        指定した角度にセットします。

        Arguments:
            distance (Number, mm): ロボットの距離。
            angle (Number, deg): ロボットの向きの角度。
        """

    @overload
    def settings(
        self,
        straight_speed: Optional[Number] = None,
        straight_acceleration: Optional[Number] = None,
        turn_rate: Optional[Number] = None,
        turn_acceleration: Optional[Number] = None,
    ) -> None: ...

    @overload
    def settings(self) -> Tuple[int, int, int, int]: ...

    def settings(self, *args):
        """
        settings(straight_speed, straight_acceleration, turn_rate, turn_acceleration)
        settings() -> Tuple[int, int, int, int]

        ドライブベースの速さと加速度を設定します。

        引数を指定しないと、今の値がタプルで返されます。

        初期値は、車輪の直径と車軸の幅をもとに自動で設定されます。
        ロボットが最大の速さの約40%で走るように選ばれています。

        ここで指定した速さの値は :meth:`.drive` メソッドには
        適用されません。そのメソッドでは、速さの値を引数として
        自分で指定するからです。

        Arguments:
            straight_speed (Number, mm/s): ロボットの直進の速さ。
            straight_acceleration (Number, mm/s²): ロボットの直進の
                加速度と減速度。2つの値のタプルを指定すると、
                加速度と減速度を別々に設定できます。
            turn_rate (Number, deg/s): ロボットの回転の速さ。
            turn_acceleration (Number, deg/s²): ロボットの回転の
                加速度と減速度。2つの値のタプルを指定すると、
                加速度と減速度を別々に設定できます。
        """

    def straight(
        self, distance: Number, then: Stop = Stop.HOLD, wait: bool = True
    ) -> MaybeAwaitable:
        """straight(distance, then=Stop.HOLD, wait=True)

        指定した距離だけまっすぐ進んで、止まります。

        Arguments:
            distance (Number, mm): 進む距離
            then (Stop): 止まった後にどうするか。
            wait (bool): プログラムの続きを始める前に、
                         動きが終わるのを待つかどうか。
        """

    def turn(
        self, angle: Number, then: Stop = Stop.HOLD, wait: bool = True
    ) -> MaybeAwaitable:
        """turn(angle, then=Stop.HOLD, wait=True)

        指定した角度だけその場で曲がって、止まります。

        Arguments:
            angle (Number, deg): 曲がる角度。
            then (Stop): 止まった後にどうするか。
            wait (bool): プログラムの続きを始める前に、
                         動きが終わるのを待つかどうか。
        """

    def arc(
        self,
        radius: Number,
        angle: Number = None,
        distance: Number = None,
        then: Stop = Stop.HOLD,
        wait: bool = True,
    ) -> MaybeAwaitable:
        """arc(radius, angle=None, distance=None, then=Stop.HOLD, wait=True)

        指定した半径（はんけい）の円弧（えんこ）（円の一部）を描いて
        走ります。どれだけ進むかは、角度か距離のどちらかで
        指定できます。

        プラスの半径では、ロボットは右側の円に沿って走ります。
        マイナスの半径では、ロボットは左側の円に沿って走ります。

        その円に沿ってどれだけ進むかは、角度（度）か距離（mm）で
        指定できます。プラスの値は、円に沿って前進することを
        意味します。マイナスは後退です。

        Arguments:
            radius (Number, mm): 円の半径。
            angle (Number, deg): 円に沿って進む角度。
            distance (Number, mm): 円に沿って進む距離。
                                   ロボットの中心ではかります。
            then (Stop): 止まった後にどうするか。
            wait (bool): プログラムの続きを始める前に、
                         動きが終わるのを待つかどうか。
        Raises:
            ValueError:
                ``angle`` か ``distance`` のどちらかを指定しなければ
                なりません。両方は指定できません。半径は 0 には
                できません。その場で曲がるときは :meth:`.turn` を
                使ってください。
        """

    def curve(
        self, radius: Number, angle: Number, then: Stop = Stop.HOLD, wait: bool = True
    ) -> MaybeAwaitable:
        """curve(radius, angle, then=Stop.HOLD, wait=True)

        指定した半径の円に沿って、指定した角度だけ円弧を描いて
        走ります。

        Arguments:
            radius (Number, mm): 円の半径。
            angle (Number, deg): 円に沿った角度。
            then (Stop): 止まった後にどうするか。
            wait (bool): プログラムの続きを始める前に、
                         動きが終わるのを待つかどうか。
        """

    def done(self) -> bool:
        """done() -> bool

        実行中の命令や動きが終わったかどうかを調べます。

        Returns:
            命令が終わっていたら ``True``、終わっていなければ ``False``。
        """

    def stalled(self) -> bool:
        """stalled() -> bool

        ドライブベースが今ストールしている（止まってしまっている）
        かどうかを調べます。

        最大の力を出しても目標の速さや位置に届かないとき、
        ストールしています。

        Returns:
            ストールしていたら ``True``、していなければ ``False``。
        """

    def use_gyro(self, use_gyro: bool) -> None:
        """use_gyro(use_gyro)

        ``True`` を選ぶと、曲がったりまっすぐ進んだりするときに
        ジャイロセンサーを使います。``False`` を選ぶと、モーターに
        内蔵された回転センサーだけを使います。

        このメソッドは自動で :meth:`.stop` を呼び出して、
        実行中の動きを止めます。

        Arguments:
            use_gyro (bool): 有効にするときは ``True``、無効にするときは ``False``。
        """


class Car:
    """A vehicle with one steering motor, and one or more motors for driving.

    When you use this class, the steering motor will automatically find the
    center position. This also determines which angle corresponds to 100%
    steering.
    """

    def __init__(
        self,
        steer_motor: Motor,
        drive_motors: Motor | Tuple[Motor, ...],
        torque_limit: Number = 100,
    ):
        """Car(steer_motor, drive_motors, torque_limit=100)

        Arguments:
            steer_motor (Motor):
                The motor that steers the front wheels.
            drive_motors (Motor): The motor that drives the wheels. Use a tuple
                for multiple motors.
            torque_limit (Number, %): The maximum torque limit used to find the
                endpoints for the steering mechanism, as a percentage of the
                maximum torque of the steering motor.
        """

    def steer(self, percentage: Number) -> None:
        """steer(percentage)

        Steers the front wheels by a given amount. For 100% steering, it
        steers right by the angle that was determined on initialization.
        For -100% steering, it steers left and 0% means straight.

        Arguments:
            steering (Number, %): Amount to steer the front wheels.
        """

    def drive_power(self, power: Number) -> None:
        """drive_power(power)

        Drives the car at a given power level. Positive values drive forward,
        negative values drive backward.

        The ``power`` value is used to set the motor voltage as a percentage of
        the battery voltage. Below 10%, the car will coast the wheels in order
        to roll out smoothly instead of braking abruptly.

        This command is useful for remote control applications where you want
        instant response to button presses or joystick movements.

        Arguments:
            speed (Number, %): Speed of the car.
        """

    def drive_speed(self, speed: Number) -> None:
        """drive_speed(speed)

        Drives the car at a given motor speed. Positive values drive forward,
        negative values drive backward.

        This command is useful for more precise driving with gentle
        acceleration and deceleration. This automatically increases the power
        to maintain speed as you drive across obstacles.

        Arguments:
            speed (Number, deg/s): Angular velocity of the drive motors.
        """


# HACK: hide from jedi
if TYPE_CHECKING:
    del Motor
    del Number
    del MaybeAwaitable
    del Stop
