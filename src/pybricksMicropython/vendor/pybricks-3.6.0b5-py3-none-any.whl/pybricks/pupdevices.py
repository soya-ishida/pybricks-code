# SPDX-License-Identifier: MIT
# Copyright (c) 2018-2023 The Pybricks Authors

"""LEGO® Powered Up motor, sensors, and lights."""

from __future__ import annotations

from typing import TYPE_CHECKING, Collection, Optional, Union, overload

from . import _common
from .parameters import Button, Color, Direction

if TYPE_CHECKING:
    from ._common import (
        MaybeAwaitable,
        MaybeAwaitableBool,
        MaybeAwaitableFloat,
        MaybeAwaitableInt,
        MaybeAwaitableTuple,
    )
    from .parameters import Number, Port


class DCMotor(_common.DCMotor):
    """LEGO® Powered Up motor without rotation sensors."""

    # HACK: jedi can't find inherited __init__ so we have to duplicate docs
    def __init__(self, port: Port, positive_direction: Direction = Direction.CLOCKWISE):
        """__init__(port, positive_direction=Direction.CLOCKWISE)

        Arguments:
            port (Port): Port to which the motor is connected.
            positive_direction (Direction): Which direction the motor should
                turn when you give a positive duty cycle value.
        """


class Motor(_common.Motor):
    """回転センサーが付いている LEGO® Powered Up モーター。"""

    # HACK: jedi can't find inherited __init__ so we have to duplicate docs
    def __init__(
        self,
        port: Port,
        positive_direction: Direction = Direction.CLOCKWISE,
        gears: Optional[Union[Collection[int], Collection[Collection[int]]]] = None,
        reset_angle: bool = True,
        profile: Number = None,
    ):
        """__init__(port, positive_direction=Direction.CLOCKWISE, gears=None, reset_angle=True, profile=None)

        Arguments:
            port (Port): モーターがつながっているポート。
            positive_direction (Direction): プラスの速さや角度を
                指定したときに、モーターが回る向き。
            gears (list):
                モーターにつながっているギアのリスト。モーターに
                つながっているギアが最初で、出力側につながっている
                ギアが最後です。

                例: ``[12, 36]`` は、モーターに12歯のギアが、出力側に
                36歯のギアがつながっていることを表します。ギアの
                組み合わせが複数あるときは、リストのリストを使います。
                例: ``[[12, 36], [20, 16, 40]]``。

                ギアの組み合わせを指定すると、モーターへの命令や
                設定はすべて、ギア比に合わせて自動で調整されます。
                モーターの回る向きはこれによって変わりません。
            reset_angle (bool):
                ``True`` を選ぶと、回転センサーの値を絶対マーカーの
                角度（-180 から 179）にリセットします。
                ``False`` を選ぶと今の値をそのまま使うので、
                前回どこまで回ったかをプログラムが覚えていられます。
            profile (Number, deg): 精度（せいど）の設定です。位置が目標から
                どれくらいずれてもよいかを、角度で表したおおよその
                値です。小さい値だと正確に止まりますが、動きが
                落ち着かなくなります。大きい値だと正確さは下がりますが、
                なめらかに動きます。値を指定しないと、このモーターに
                合った設定が自動で選ばれます（約11度）。
        """

    def reset_angle(self, angle: Optional[Number] = None) -> None:
        """reset_angle(angle=None)

        モーターが回った角度の合計を、好きな値にセットします。

        このモーターをドライブベースにも使っている場合、その距離と
        角度の値も変わります。ドライブベースの
        :meth:`reset <pybricks.robotics.DriveBase.reset>`
        メソッドを使うほうがよいかもしれません。

        Arguments:
            angle (Number, deg): 角度をリセットする値。
                                 ``None`` を選ぶと、モーターの絶対値に
                                 リセットします。
        """


class Remote:
    """LEGO® Powered Up Bluetooth Remote Control."""

    light = _common.ExternalColorLight()
    buttons = _common.Keypad(
        (
            Button.LEFT_MINUS,
            Button.RIGHT_MINUS,
            Button.LEFT,
            Button.CENTER,
            Button.RIGHT,
            Button.LEFT_PLUS,
            Button.RIGHT_PLUS,
        )
    )
    address: Union[str, None]

    def __init__(self, name: Optional[str] = None, timeout: int = 10000):
        """Remote(name=None, timeout=10000)

        When you instantiate this class, the hub will search for a remote
        and connect automatically.

        The remote must be on and ready for a connection, as indicated by a
        white blinking light.

        Arguments:
            name (str): Bluetooth name of the remote. If no name is given,
                the hub connects to the first remote that it finds.
            timeout (Number, ms): How long to search for the remote.
        """

    @overload
    def name(self, name: str) -> None: ...

    @overload
    def name(self) -> str: ...

    def name(self, *args):
        """name(name)
        name() -> str

        Sets or gets the Bluetooth name of the remote.

        Arguments:
            name (str): New Bluetooth name of the remote. If no name is given,
                this method returns the current name.
        """

    def disconnect(self) -> MaybeAwaitable:
        """disconnect()

        Disconnects the remote from the hub.
        """


class TiltSensor:
    """LEGO® Powered Up Tilt Sensor."""

    def __init__(self, port: Port):
        """TiltSensor(port)

        Arguments:
            port (Port): Port to which the sensor is connected.
        """

    def tilt(self) -> MaybeAwaitableTuple[int, int]:
        """tilt() -> Tuple[int, int]: deg

        Measures the tilt relative to the horizontal plane.

        Returns:
            Tuple of pitch and roll angles.
        """


class ColorDistanceSensor(_common.CommonColorSensor):
    """LEGO® Powered Up Color and Distance Sensor."""

    light = _common.ExternalColorLight()

    # HACK: jedi can't find inherited __init__ so docs have to be duplicated
    def __init__(self, port: Port):
        """__init__(port)

        Arguments:
            port (Port): Port to which the sensor is connected.
        """

    def distance(self) -> MaybeAwaitableInt:
        """distance() -> int: %

        Measures the relative distance between the sensor and an object
        using infrared light.

        Returns:
            Distance ranging from 0% (closest) to 100% (farthest).
        """


class PFMotor:
    """Control Power Functions motors with the infrared functionality of the
    :class:`ColorDistanceSensor <pybricks.pupdevices.ColorDistanceSensor>`."""

    def __init__(
        self,
        sensor: ColorDistanceSensor,
        channel: int,
        color: Color,
        positive_direction: Direction = Direction.CLOCKWISE,
    ):
        """PFMotor(sensor, channel, color, positive_direction=Direction.CLOCKWISE)

        Arguments:
            sensor (ColorDistanceSensor):
                Sensor object.
            channel (int):
                Channel number of the receiver: ``1``, ``2``, ``3``, or ``4``.
            color (Color):
                Color marker on the receiver:
                :class:`Color.BLUE <.parameters.Color>` or
                :class:`Color.RED <.parameters.Color>`
            positive_direction (Direction): Which direction the motor should
                turn when you give a positive duty cycle value.
        """

    def dc(self, duty: Number) -> MaybeAwaitable:
        """dc(duty)

        Rotates the motor at a given duty cycle (also known as "power").

        Arguments:
            duty (Number, %): The duty cycle (-100.0 to 100).
        """

    def stop(self) -> MaybeAwaitable:
        """stop()

        Stops the motor and lets it spin freely.

        The motor gradually stops due to friction.
        """

    def brake(self) -> MaybeAwaitable:
        """brake()

        Passively brakes the motor.

        The motor stops due to friction, plus the voltage that
        is generated while the motor is still moving.
        """


class ColorSensor(_common.AmbientColorSensor):
    """LEGO® SPIKE カラーセンサー。"""

    lights = _common.LightArray3()

    # HACK: jedi can't find inherited __init__ so docs have to be duplicated
    def __init__(self, port: Port):
        """__init__(port)

        Arguments:
            port (Port): センサーがつながっているポート。
        """


class UltrasonicSensor:
    """LEGO® SPIKE 超音波センサー。"""

    lights = _common.LightArray4()

    def __init__(self, port: Port):
        """UltrasonicSensor(port)

        Arguments:
            port (Port): センサーがつながっているポート。
        """

    def distance(self) -> MaybeAwaitableInt:
        """distance() -> int: mm

        超音波を使って、センサーから物までの距離をはかります。

        Returns:
            はかった距離。うまくはかれなかったときは
            2000 mm を返します。
        """

    def presence(self) -> MaybeAwaitableBool:
        """presence() -> bool

        超音波の音を感じ取って、ほかの超音波センサーがあるかどうかを
        調べます。

        Returns:
            超音波の音を感じ取ったら ``True``、感じ取らなければ ``False``。
        """


class ForceSensor:
    """LEGO® SPIKE フォースセンサー。"""

    def __init__(self, port: Port):
        """ForceSensor(port)

        Arguments:
            port (Port): センサーがつながっているポート。
        """

    def force(self) -> MaybeAwaitableFloat:
        """force() -> float: N

        センサーにかかっている力をはかります。

        Returns:
            はかった力（最大で約 10.00 N）。
        """

    def distance(self) -> MaybeAwaitableFloat:
        """distance() -> float: mm

        センサーのボタンがどれくらい押し込まれたかをはかります。

        Returns:
            押し込まれた量（最大で約 8.00 mm）。
        """

    def pressed(self, force: Number = 3) -> MaybeAwaitableBool:
        """pressed(force=3) -> bool

        センサーのボタンが押されているかどうかを調べます。

        Arguments:
            force (Number, N): 押されたと判断する力の最小値。

        Returns:
            センサーが押されていたら ``True``、押されていなければ ``False``。
        """

    def touched(self) -> MaybeAwaitableBool:
        """touched() -> bool

        センサーに触れているかどうかを調べます。

        :meth:`pressed` と似ていますが、はかった力がまだ 0 と
        みなされるくらい小さいボタンの動きでも感じ取ります。

        Returns:
            センサーに触れているか押されていたら ``True``、
            そうでなければ ``False``。
        """


class ColorLightMatrix:
    """
    LEGO® SPIKE 3x3 Color Light Matrix.
    """

    def __init__(self, port: Port):
        """ColorLightMatrix(port)

        Arguments:
            port (Port): Port to which the device is connected.

        """
        ...

    def on(self, color: Union[Color, Collection[Color]]) -> MaybeAwaitable:
        """on(colors)

        Turns the lights on.

        Arguments:
            colors (Color or list):
                If a single :class:`.Color` is given, then all 9 lights are set
                to that color. If a list of colors is given, then each light is
                set to that color.
        """
        ...

    def off(self) -> MaybeAwaitable:
        """off()

        Turns all lights off.
        """
        ...


class InfraredSensor:
    """LEGO® Powered Up Infrared Sensor."""

    def __init__(self, port: Port):
        """InfraredSensor(port)

        Arguments:
            port (Port): Port to which the sensor is connected.
        """

    def reflection(self) -> MaybeAwaitableInt:
        """reflection() -> int: %

        Measures the reflection of a surface using an infrared light.

        Returns:
            Measured reflection, ranging from 0% (no reflection) to
            100% (high reflection).
        """

    def distance(self) -> MaybeAwaitableInt:
        """distance() -> int: %

        Measures the relative distance between the sensor and an object
        using infrared light.

        Returns:
            Distance ranging from 0% (closest) to 100% (farthest).
        """

    def count(self) -> MaybeAwaitableInt:
        """count() -> int

        Counts the number of objects that have passed by the sensor.

        Returns:
            Number of objects counted.
        """


class Light:
    """LEGO® Powered Up Light."""

    def __init__(self, port: Port):
        """Light(port)

        Arguments:
            port (Port): Port to which the device is connected.
        """

    def on(self, brightness: Number = 100) -> None:
        """on(brightness=100)

        Turns on the light at the specified brightness.

        Arguments:
            brightness (Number, %):
                Brightness of the light.
        """

    def off(self) -> None:
        """off()

        Turns off the light."""


# HACK: exclude from jedi
if TYPE_CHECKING:
    del Button
    del Color
    del Direction
    del MaybeAwaitable
    del MaybeAwaitableBool
    del MaybeAwaitableFloat
    del MaybeAwaitableInt
    del MaybeAwaitableTuple
    del Number
    del Port
